import { Outlet } from "react-router-dom";
import { useWindowSize } from "../providers/WindowSizeProvider";
import { useTheme } from "../providers/ThemeProvider";
import { useState, useEffect } from "react";
import Divider from '@mui/material/Divider';
import MenuIcon from '@mui/icons-material/Menu';
import IconHover from "../components/IconHover";


const pages = [
    { name: "Home", path: "/home" },
    { name: "About", path: "/about" }
];

export default function Layout() {
    const { width } = useWindowSize();
    const { theme } = useTheme();

    const [headerHeight, setHeaderHeight] = useState(80);
    const [sidebarWidth, setSidebarWidth] = useState(200);
    const [openSidebar, setOpenSidebar] = useState(false);
    const [smallScreen, setSmallScreen] = useState(false);

    useEffect(() => {
        setHeaderHeight(width > 800 ? 70 : 60);
        setSmallScreen(width > 800 ? false : true)
    }, [width]);




    return (
        <div style={{
            position: "relative",
            width: "100%",
            left: 0,
            top: 0,
            height: "100%",
            background: "red",
            overflow: "hidden"
        }}>

            <header style={{ height: headerHeight, background: theme.header, borderBottom: `1px solid ${theme.border}`, display: "flex", }}>
                <div style={{ display: "flex", gap: 20, alignItems: "center", paddingLeft: "20px" }}>
                    <img src="logo.png" height={50} alt="" srcset="" />
                    <Divider orientation="vertical" flexItem />
                    <IconHover onClick={() => setOpenSidebar(!openSidebar)} icon={<MenuIcon />} />
                </div>
            </header>

            {openSidebar && <aside style={{zIndex: 3, position: "fixed", left: 0, top: 0, background: "green", width: sidebarWidth, height: "100%", top: headerHeight + 1 }}>

            </aside>}
            {smallScreen && openSidebar && <div onClick={() => setOpenSidebar(false)} style={{zIndex: 2, position: "fixed", left: 0, width: "100%", height: "100%", background: "black", opacity: 0.2, }} />}

            <div style={{ overflowY: "auto", position: "fixed", height: `calc(100% - ${headerHeight+41}px)`, width: !smallScreen && openSidebar ? `calc(100% - ${sidebarWidth+40}px)` : `calc(100% - ${40}px)`, left: !smallScreen && openSidebar && sidebarWidth + 1, bottom: 0, display: "flex", justifyContent: "space-between", background: "red", padding: 20 }}>
                <Outlet/>
            </div>


        </div>


    );
}