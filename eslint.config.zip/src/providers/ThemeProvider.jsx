import { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error('useTheme must be used within a ThemeProvider');
    }
    return context;
};




const palettes = {
    default: {
        background: "#ffffff",
        card: "#ffffff",
        cardBox: "#f3f3f3ff",
        header: "#ffffff",
        border: "#d4d4d4ff",
        main: "#007accff",
        text1: "#1a1a1a",
        text2: "#4a4a4a",
        textContrast1: "#fff",
        textContrast2: "#e6f3ff",
        hover: "#c5e6ffff",
        lightHover: "#f0f9ffff",
        darkHover: "#b3dfff",
        icon: "#333",
        iconContrast: "#fff",
        tableHeader: "#daeefdff",
        tableRow1: "#f7fbff",
        tableRow2: "#ffffff",
        chart1: "#007accff",
        chart2: "#00bcd4ff",
        chart3: "#ef5350ff",
        chart4: "#26a69aff",
        chart5: "#5c6bc0ff",
        chart6: "#1565c0ff",
        pieBack: "#cbcbcbff",
        button: "#007accff",
        cancelButton: "#90caf9ff",
        clearButton: "#ef5350ff",
        tooltip: "#555",
        error: "#ef5350ff",
        warning: "#ffde26ff",
        success: "#26a69aff",
    },
    dark: {
        // FONDOS: Escala de grises pura. El más oscuro para el fondo base, aclarando hacia arriba.
        background: "#121212", // Negro suave (mejor que #000 puro para Oled)
        card: "#333",       // Gris muy oscuro para contenedores
        cardBox: "#2b2b2bff",
        header: "#252525",     // Gris medio oscuro para cabeceras
        border: "#666666",     // Gris oscuro para bordes sutiles

        // MAIN: Blanco para mantener la monocromía estricta.
        main: "#6ab0ffff",

        // TEXTOS: Escala de grises desde blanco puro hasta gris medio.
        text1: "#ffffff",      // Títulos y texto principal (Máximo contraste)
        text2: "#b0b0b0",      // Texto secundario (Gris medio, reduce fatiga)
        textContrast1: "#000000", // Texto negro para botones blancos
        textContrast2: "#ffffff", // Texto blanco para fondos oscuros

        // HOVERS: Opacidades de blanco sobre el fondo gris.
        hover: "#ffffff33",    // Blanco con 20% de opacidad
        lightHover: "#ffffff1a", // Blanco con 10% de opacidad
        darkHover: "#ffffff66",  // Blanco con 40% de opacidad

        // ICONOS
        icon: "#e0e0e0",       // Blanco roto (casi puro)
        iconContrast: "#000000", // Negro para fondos claros

        // TABLAS: Alternancia de grises para lectura.
        tableHeader: "#2c2c2c", // Gris oscuro medio
        tableRow1: "#252525",   // Un poco más claro que la tarjeta
        tableRow2: "#1e1e1e",   // Igual que la tarjeta

        // GRÁFICOS: Aquí SÍ usamos color. 
        // Si los gráficos fueran grises, serían ilegibles sobre fondo gris.
        chart1: "#ff6b6b",     // Rojo pastel
        chart2: "#4ecdc4",     // Turquesa
        chart3: "#ffe66d",     // Amarillo
        chart4: "#1a535c",     // Verde azulado oscuro (para contraste fuerte)
        chart5: "#ff9f43",     // Naranja
        chart6: "#a55eea",     // Púrpura
        pieBack: "#888",

        // BOTONES
        button: "#ffffff",     // Botón principal blanco (estilo minimalista)
        cancelButton: "#94abb7ff", // Gris medio (botón secundario)
        clearButton: "#ef5350",  // Mantenemos el rojo para acción destructiva (necesario para seguridad UI)

        // TOOLTIP
        tooltip: "#000000",    // Negro puro para máximo contraste

        // SEMÁNTICOS: Colores estándar de estado (necesarios para entender la UI).
        error: "#ef5350",
        warning: "#ffde26",
        success: "#26a69a",
    }
};

export const ThemeProvider = ({ children }) => {
    const [mode, setMode] = useState(() => {
        return localStorage.getItem("theme") || "default";
    });

    useEffect(() => {
        localStorage.setItem("theme", mode);
    }, [mode]);

    const changeTheme = (t) => {
        setMode(t);
    };

    const theme = palettes[mode];

    return (
        <ThemeContext.Provider value={{ theme, changeTheme, mode, setMode }}>
            {children}
        </ThemeContext.Provider>
    );
};